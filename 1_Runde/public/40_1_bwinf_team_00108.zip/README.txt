##### Zu Dokumentation.pdf #####

Dokumentation.pdf enthält die Dokumentationen für alle drei abgegeben Aufgaben. In den jeweiligen Aufgabenordnern sind aber auch noch Kopien von Dokumentation.pdf enthalten.